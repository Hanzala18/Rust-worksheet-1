fn factorial(x:u64) -> u64{
    if x ==0{
        return 1;
    }x * factorial(x-1)
}
fn main() {
    let x = 4;
    let result = factorial(x);
    println!("{} factorial is {}",x,result);
}
