use std::io;

fn cel_to_fr(celsius: f64) -> f64 { //  of cerlcius to farenhiete
    (celsius * 9.0 / 5.0) + 32.0
}

fn fr_to_cel(fahrenheit: f64) -> f64 {// farenhiete to celcius
    (fahrenheit - 32.0) * 5.0 / 9.0
}

fn main() {
    println!("Enter the temperature");

    let mut temperature = String::new();
    io::stdin().read_line(&mut temperature).expect("Error");

    let temperature: f64 = temperature.trim().parse().expect("Invalid input");//trim remove spaces || parse change triminto float

    println!("Enter the option in which you want to convert ");
    println!("1 => Celsius to Fahrenheit");
    println!("2 => Fahrenheit to Celsius");

    let mut option = String::new();
    io::stdin().read_line(&mut option).expect("Not an option");
    let option: u32 = option.trim().parse().expect("Invalid option");

    let converted_temperature: f64 = match option {
        1 => cel_to_fr(temperature),
        2 => fr_to_cel(temperature),
        _ => {
            println!("Invalid option");
            return;
        }
    };

    println!("Converted temperature is {}", converted_temperature);
}
