fn main() {
    let x: i32 = 3;
    if x % 2==0{
        println!("even");
    }else{
        println!("odd");
    }
}
